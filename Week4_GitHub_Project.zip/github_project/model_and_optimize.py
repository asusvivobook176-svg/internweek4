import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, GridSearchCV, KFold, cross_val_score
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

np.random.seed(42)
sns.set_theme(style="whitegrid", palette="deep")
COLOR = "#1F4E78"

# ---------------------------------------------------------------
# 1. Simulate dataset (same structure/logic as Week 3, regenerated)
# ---------------------------------------------------------------
n = 3000
regions = ["North", "South", "East", "West", "Central"]
modes = ["Standard", "Express", "Same Day", "Economy"]

region_arr = np.random.choice(regions, size=n, p=[0.22, 0.2, 0.22, 0.18, 0.18])
mode_arr = np.random.choice(modes, size=n, p=[0.45, 0.25, 0.1, 0.2])

region_base_distance = {"North": 180, "South": 220, "East": 150, "West": 260, "Central": 90}
distance_km = np.array([max(5, np.random.normal(region_base_distance[r], 60)) for r in region_arr])

order_volume = np.random.poisson(lam=6, size=n) + 1

mode_speed_factor = {"Standard": 1.0, "Express": 0.55, "Same Day": 0.15, "Economy": 1.4}
base_time = distance_km / 35
noise = np.random.normal(0, 3, size=n)
delivery_time_hours = np.clip(
    [base_time[i] * mode_speed_factor[mode_arr[i]] * 24 + noise[i] + np.random.exponential(4) for i in range(n)],
    1, None
)

mode_surcharge = {"Standard": 0, "Express": 18, "Same Day": 40, "Economy": -5}
transport_cost = (
    12 + distance_km * 0.35 + order_volume * 1.8
    + np.array([mode_surcharge[m] for m in mode_arr])
    + np.random.normal(0, 6, size=n)
)
transport_cost = np.clip(transport_cost, 5, None)

outlier_idx = np.random.choice(n, size=35, replace=False)
distance_km[outlier_idx] *= np.random.uniform(3, 6, size=35)
transport_cost[outlier_idx] *= np.random.uniform(1.5, 2.5, size=35)

start = pd.Timestamp("2025-01-01")
order_date = start + pd.to_timedelta(np.random.randint(0, 365, size=n), unit="D")
day_of_week = order_date.dayofweek

df = pd.DataFrame({
    "region": region_arr,
    "shipping_mode": mode_arr,
    "distance_km": distance_km.round(1),
    "order_volume": order_volume,
    "day_of_week": day_of_week,
    "transport_cost": transport_cost.round(2),
    "delivery_time_hours": delivery_time_hours.round(1),
})
df.to_csv("logistics_model_data.csv", index=False)
print(df.head())
print(df.shape)

# ---------------------------------------------------------------
# 2. Problem: predict delivery_time_hours (regression)
# ---------------------------------------------------------------
target = "delivery_time_hours"
num_features = ["distance_km", "order_volume", "day_of_week", "transport_cost"]
cat_features = ["region", "shipping_mode"]

X = df[num_features + cat_features]
y = df[target]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

preprocessor = ColumnTransformer(transformers=[
    ("cat", OneHotEncoder(drop="first"), cat_features),
], remainder="passthrough")

# --- Baseline: Linear Regression ---
lr_pipeline = Pipeline([
    ("prep", preprocessor),
    ("model", LinearRegression()),
])
lr_pipeline.fit(X_train, y_train)
lr_pred = lr_pipeline.predict(X_test)

# --- Candidate: Random Forest ---
rf_pipeline = Pipeline([
    ("prep", preprocessor),
    ("model", RandomForestRegressor(random_state=42)),
])

param_grid = {
    "model__n_estimators": [100, 200],
    "model__max_depth": [None, 8, 12],
    "model__min_samples_leaf": [1, 3],
}
kfold = KFold(n_splits=5, shuffle=True, random_state=42)
grid = GridSearchCV(rf_pipeline, param_grid, cv=kfold, scoring="neg_root_mean_squared_error", n_jobs=-1)
grid.fit(X_train, y_train)
best_rf = grid.best_estimator_
rf_pred = best_rf.predict(X_test)

cv_scores = cross_val_score(best_rf, X_train, y_train, cv=kfold, scoring="r2")

def metrics(y_true, y_pred):
    return {
        "MAE": mean_absolute_error(y_true, y_pred),
        "RMSE": np.sqrt(mean_squared_error(y_true, y_pred)),
        "R2": r2_score(y_true, y_pred),
    }

lr_metrics = metrics(y_test, lr_pred)
rf_metrics = metrics(y_test, rf_pred)

print("Linear Regression:", lr_metrics)
print("Random Forest (tuned):", rf_metrics)
print("Best params:", grid.best_params_)
print("CV R2 scores:", cv_scores, "mean:", cv_scores.mean())

# ---------------------------------------------------------------
# 3. Visualization: Actual vs Predicted (Random Forest)
# ---------------------------------------------------------------
plt.figure(figsize=(6.5, 6))
plt.scatter(y_test, rf_pred, alpha=0.4, color=COLOR, s=25)
lims = [0, max(y_test.max(), rf_pred.max()) * 1.05]
plt.plot(lims, lims, "--", color="#D9534F", linewidth=2, label="Perfect Prediction")
plt.xlabel("Actual Delivery Time (hours)")
plt.ylabel("Predicted Delivery Time (hours)")
plt.title("Actual vs. Predicted Delivery Time (Random Forest)", fontsize=13, fontweight="bold")
plt.legend()
plt.tight_layout()
plt.savefig("images/01_actual_vs_predicted.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 4. Visualization: Residual plot
# ---------------------------------------------------------------
residuals = y_test.values - rf_pred
plt.figure(figsize=(7, 4.5))
sns.scatterplot(x=rf_pred, y=residuals, alpha=0.4, color=COLOR, s=25)
plt.axhline(0, color="#D9534F", linestyle="--", linewidth=2)
plt.xlabel("Predicted Delivery Time (hours)")
plt.ylabel("Residual (Actual − Predicted)")
plt.title("Residual Plot — Random Forest Model", fontsize=13, fontweight="bold")
plt.tight_layout()
plt.savefig("images/02_residual_plot.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 5. Visualization: Feature importance
# ---------------------------------------------------------------
ohe = best_rf.named_steps["prep"].named_transformers_["cat"]
cat_names = list(ohe.get_feature_names_out(cat_features))
feature_names = cat_names + num_features
importances = best_rf.named_steps["model"].feature_importances_
fi = pd.Series(importances, index=feature_names).sort_values(ascending=True)

plt.figure(figsize=(7.5, 5.5))
fi.plot(kind="barh", color="#2E75B6")
plt.title("Feature Importance — Random Forest Model", fontsize=13, fontweight="bold")
plt.xlabel("Relative Importance")
plt.tight_layout()
plt.savefig("images/03_feature_importance.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 6. Visualization: Model comparison bar chart
# ---------------------------------------------------------------
comp_df = pd.DataFrame({
    "Linear Regression": lr_metrics,
    "Random Forest (Tuned)": rf_metrics,
}).T
plt.figure(figsize=(7, 4.5))
comp_df[["MAE", "RMSE"]].plot(kind="bar", ax=plt.gca(), color=["#9DC3E6", "#1F4E78"])
plt.title("Model Comparison: MAE and RMSE (lower is better)", fontsize=13, fontweight="bold")
plt.ylabel("Hours")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig("images/04_model_comparison.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 7. Optimization: warehouse-to-region allocation (Linear Programming)
# ---------------------------------------------------------------
import pulp

warehouses = ["WH_Central", "WH_North", "WH_West"]
warehouse_capacity = {"WH_Central": 1400, "WH_North": 1000, "WH_West": 900}
region_demand = {"North": 620, "South": 580, "East": 640, "West": 560, "Central": 500}

# approximate per-km cost using model insight (transport_cost ~ 0.35/km + base)
# distance matrix (km) from each warehouse to each region hub (illustrative)
distance_matrix = {
    ("WH_Central", "North"): 210, ("WH_Central", "South"): 240, ("WH_Central", "East"): 200,
    ("WH_Central", "West"): 260, ("WH_Central", "Central"): 40,
    ("WH_North", "North"): 60, ("WH_North", "South"): 380, ("WH_North", "East"): 300,
    ("WH_North", "West"): 420, ("WH_North", "Central"): 210,
    ("WH_West", "North"): 430, ("WH_West", "South"): 360, ("WH_West", "East"): 480,
    ("WH_West", "West"): 70, ("WH_West", "Central"): 260,
}
cost_per_km = 0.35
shipping_cost = {k: 12 + v * cost_per_km for k, v in distance_matrix.items()}

prob = pulp.LpProblem("Warehouse_Allocation", pulp.LpMinimize)
ship = {(w, r): pulp.LpVariable(f"ship_{w}_{r}", lowBound=0) for w in warehouses for r in region_demand}

prob += pulp.lpSum(shipping_cost[(w, r)] * ship[(w, r)] for w in warehouses for r in region_demand)

for r in region_demand:
    prob += pulp.lpSum(ship[(w, r)] for w in warehouses) >= region_demand[r], f"demand_{r}"
for w in warehouses:
    prob += pulp.lpSum(ship[(w, r)] for r in region_demand) <= warehouse_capacity[w], f"capacity_{w}"

prob.solve(pulp.PULP_CBC_CMD(msg=0))

alloc_rows = []
for w in warehouses:
    for r in region_demand:
        val = ship[(w, r)].value()
        if val and val > 0.5:
            alloc_rows.append((w, r, round(val, 1), round(shipping_cost[(w, r)], 2)))

total_cost = pulp.value(prob.objective)
print("\nOptimization status:", pulp.LpStatus[prob.status])
print("Total optimized shipping cost:", total_cost)
for row in alloc_rows:
    print(row)

# naive baseline: each region served entirely by nearest-by-name central warehouse (no optimization)
naive_cost = sum(region_demand[r] * shipping_cost[("WH_Central", r)] for r in region_demand)
savings_pct = (naive_cost - total_cost) / naive_cost * 100

# ---------------------------------------------------------------
# 8. Visualization: optimized allocation heatmap
# ---------------------------------------------------------------
alloc_matrix = pd.DataFrame(0.0, index=warehouses, columns=list(region_demand.keys()))
for w, r, val, _ in alloc_rows:
    alloc_matrix.loc[w, r] = val

plt.figure(figsize=(7, 4.5))
sns.heatmap(alloc_matrix, annot=True, fmt=".0f", cmap="Blues", cbar_kws={"label": "Units Allocated"})
plt.title("Optimized Warehouse-to-Region Allocation", fontsize=13, fontweight="bold")
plt.xlabel("Region")
plt.ylabel("Warehouse")
plt.tight_layout()
plt.savefig("images/05_optimized_allocation.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# Save summary
# ---------------------------------------------------------------
summary = {
    "n_records": n,
    "lr_metrics": lr_metrics,
    "rf_metrics": rf_metrics,
    "best_params": grid.best_params_,
    "cv_r2_mean": cv_scores.mean(),
    "cv_r2_std": cv_scores.std(),
    "top_features": fi.sort_values(ascending=False).head(5).to_dict(),
    "optimized_total_cost": total_cost,
    "naive_total_cost": naive_cost,
    "savings_pct": savings_pct,
}
with open("summary_stats.json", "w") as f:
    json.dump(summary, f, indent=2, default=str)

print("\nSavings from optimization vs naive allocation: {:.1f}%".format(savings_pct))
print("\nAll modeling and optimization artifacts generated successfully.")
