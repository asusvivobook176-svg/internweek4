# Predictive Modeling and Optimization in Logistics Systems

Week 4 project: predicts shipment delivery time using a tuned Random Forest
regressor and formulates a warehouse-to-region allocation optimization
(linear programming, PuLP) to minimize total shipping cost.

## Contents
- `model_and_optimize.py` — full pipeline: data simulation, model training
  (Linear Regression baseline + tuned Random Forest), evaluation
  (MAE/RMSE/R², 5-fold CV), and a PuLP-based warehouse allocation
  optimization, with all plots saved to `images/`.
- `requirements.txt` — Python dependencies.

## Usage
```bash
pip install -r requirements.txt
python model_and_optimize.py
```

## Results
- Random Forest (tuned): MAE ≈ 4.8 hrs, RMSE ≈ 8.9 hrs, R² ≈ 0.98
- Optimized warehouse allocation reduces total shipping cost by ~25%
  versus a naive single-warehouse allocation strategy.

See the accompanying Week 4 report (DOCX) for full methodology,
evaluation discussion, and recommendations.
